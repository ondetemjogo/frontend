parking.constant("parkingConfig", {
  parkingRate: 20
});